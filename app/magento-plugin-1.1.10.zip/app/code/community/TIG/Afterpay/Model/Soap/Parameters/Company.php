<?php 
class TIG_Afterpay_Model_Soap_Parameters_Company
{
    public $cocnumber; //KvK number
    public $companyname;
    public $department;
    public $establishmentnumber;
    public $vatnumber; //KvK number, 8 digits
}