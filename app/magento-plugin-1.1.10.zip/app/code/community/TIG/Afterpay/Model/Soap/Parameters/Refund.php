<?php 
class TIG_Afterpay_Model_Soap_Parameters_Refund extends TIG_Afterpay_Model_Soap_Parameters_OrderManagement
{
    public $creditInvoicenNumber;
}