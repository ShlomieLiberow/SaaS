<?php 
class TIG_Afterpay_Model_Soap_Parameters_B2CAddress extends TIG_Afterpay_Model_Soap_Parameters_Address
{
    public $referencePerson;
}