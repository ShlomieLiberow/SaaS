<?php 
class TIG_Afterpay_Model_Soap_Parameters_B2BAddress
{
    public $careof;
    public $phone;
}