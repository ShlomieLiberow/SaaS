<?php 
class TIG_Afterpay_Model_Soap_Parameters_Invoicelines
{
    public $articleDescription;
    public $articleID;
    public $netunitprice;
    public $quantity;
    public $unitprice;
    public $vatcategory;
}