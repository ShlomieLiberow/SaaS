<?php 
class TIG_Afterpay_Model_Soap_Parameters_ShopDetails
{
    public $afterpaypluginsupplier;
    public $afterpayPluginVersion;
    public $intermediarID;
    public $shopURL;
    public $webshoplanguage;
    public $webshopplatform;
    public $webshoplatformversion;
}