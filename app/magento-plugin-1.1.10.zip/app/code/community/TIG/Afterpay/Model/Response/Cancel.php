<?php 
class TIG_Afterpay_Model_Response_Cancel extends TIG_Afterpay_Model_Response_Refund
{    
    
}