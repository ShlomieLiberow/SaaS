<?php 
class TIG_Afterpay_Model_Soap_Parameters_Shopper
{
    public $afterPayId;
    public $afterPayToken;
    public $customerNumber;
    public $finbox;
    public $profileCreated;
    public $hasCustcard;
    public $HasPayments;
    public $referString;
    public $Fingerprint;
}