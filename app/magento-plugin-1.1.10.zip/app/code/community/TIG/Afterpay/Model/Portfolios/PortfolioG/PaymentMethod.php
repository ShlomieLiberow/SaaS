<?php
class TIG_Afterpay_Model_Portfolios_PortfolioG_PaymentMethod extends TIG_Afterpay_Model_Portfolios_Abstract
{
    protected $_code = 'portfolio_g';
}