<?php 
class TIG_Afterpay_Model_Response_BackendOrder extends TIG_Afterpay_Model_Response_Abstract
{
    
}