<?php 
class TIg_Afterpay_Model_Soap_Parameters_ExtraFields
{
    public $nameField;
    public $valueField;
}