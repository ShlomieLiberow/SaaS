<?php 
class TIG_Afterpay_Model_Soap_Parameters_OrderManagement
{
   public $extrafields;
   public $invoicelines;
   public $invoicenumber;
   public $transactionReference;
   public $transactionkey;
}