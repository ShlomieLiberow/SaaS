<?php
class TIG_Afterpay_Model_Portfolios_PortfolioB_PaymentMethod extends TIG_Afterpay_Model_Portfolios_Abstract
{
    protected $_code = 'portfolio_b';
}