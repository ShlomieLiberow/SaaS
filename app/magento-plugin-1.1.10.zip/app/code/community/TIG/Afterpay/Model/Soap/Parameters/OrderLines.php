<?php
class TIG_Afterpay_Model_Soap_Parameters_OrderLines
{
    public $orderLine;
}