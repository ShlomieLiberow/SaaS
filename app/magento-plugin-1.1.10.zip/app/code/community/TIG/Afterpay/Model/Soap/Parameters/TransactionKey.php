<?php 
class TIG_Afterpay_Model_Soap_Parameters_TransactionKey
{
    public $Ordernumber;
    public $parentTransactionreference;
}