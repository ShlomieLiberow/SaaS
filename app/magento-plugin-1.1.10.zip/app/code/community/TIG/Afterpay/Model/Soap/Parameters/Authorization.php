<?php 
class TIG_Afterpay_Model_Soap_Parameters_Authorization 
{
    public $merchantId; //is also called 'Business Partners_id' or 'relatienummer'
    public $portfolioId;
    public $password;
}