<?php
class TIG_Afterpay_Model_Portfolios_PortfolioF_PaymentMethod extends TIG_Afterpay_Model_Portfolios_Abstract
{
    protected $_code = 'portfolio_f';
}