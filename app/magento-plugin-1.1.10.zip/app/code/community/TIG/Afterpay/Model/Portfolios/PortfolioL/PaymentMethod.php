<?php
class TIG_Afterpay_Model_Portfolios_PortfolioL_PaymentMethod extends TIG_Afterpay_Model_Portfolios_Abstract
{
    protected $_code = 'portfolio_l';
}