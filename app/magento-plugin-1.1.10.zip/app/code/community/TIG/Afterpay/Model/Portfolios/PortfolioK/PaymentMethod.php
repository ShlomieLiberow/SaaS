<?php
class TIG_Afterpay_Model_Portfolios_PortfolioK_PaymentMethod extends TIG_Afterpay_Model_Portfolios_Abstract
{
    protected $_code = 'portfolio_k';
}