<?php 
class TIG_Afterpay_Model_Soap_Parameters_AfterPayB2COrder extends TIG_Afterpay_Model_Soap_Parameters_AfterPayOrder
{
    public $b2cbilltoAddress;
    public $b2cshiptoAddress;
}